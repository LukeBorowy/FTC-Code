
package org.firstinspires.ftc.teamcode;

import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import org.firstinspires.ftc.robotcore.external.navigation.AngularVelocity;
import org.firstinspires.ftc.robotcore.external.navigation.AngleUnit;
import org.firstinspires.ftc.robotcore.external.navigation.Orientation;
import org.firstinspires.ftc.robotcore.external.navigation.AxesReference;
import org.firstinspires.ftc.robotcore.external.navigation.AxesOrder;
import com.qualcomm.robotcore.hardware.IntegratingGyroscope;
import com.qualcomm.robotcore.eventloop.opmode.Autonomous;
import org.firstinspires.ftc.robotcore.external.navigation.RelicRecoveryVuMark;
import org.firstinspires.ftc.robotcore.external.navigation.VuforiaTrackables;
import org.firstinspires.ftc.robotcore.external.navigation.VuforiaTrackable;
import org.firstinspires.ftc.robotcore.external.navigation.VuforiaLocalizer;
import org.firstinspires.ftc.robotcore.external.ClassFactory;
import com.qualcomm.robotcore.eventloop.opmode.OpMode;
import com.qualcomm.robotcore.hardware.SwitchableLight;
import com.qualcomm.robotcore.hardware.VoltageSensor;
import com.qualcomm.robotcore.eventloop.opmode.TeleOp;
import com.qualcomm.robotcore.eventloop.opmode.Disabled;
import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.robotcore.hardware.DcMotorSimple;
import com.qualcomm.robotcore.util.ElapsedTime;
import com.qualcomm.robotcore.hardware.Servo;
import com.qualcomm.robotcore.hardware.CRServo;
import com.qualcomm.robotcore.hardware.ColorSensor;
import com.qualcomm.hardware.kauailabs.NavxMicroNavigationSensor;


//vuforia.com
//user: MadMachine
//pass:FTc118192017
//email: 11819@saintpeterrobotics.org

@Autonomous
public class BlueCenter extends LinearOpMode{
  private DcMotor m1;
  private DcMotor m2;  
  private DcMotor m3;
  private DcMotor m4;
  private DcMotor glyph_boom;
  double volts;
  VuforiaLocalizer vuforia;
  NavxMicroNavigationSensor navX;
  String seenVuMark="none";
  int blue;
  int red;
  int col_diff;
  float tilt=999;
  int deg=0;
  
  double correction;
  float angle=0;
  float maxTurnError=1;
  float maxMoveAngleError=1;
  AngularVelocity rates;
  Orientation angles;
  int cameraMonitorViewId;
  double error;
  double distance;
  boolean done=false;
  
  
  VuforiaLocalizer.Parameters parameters;
  
  private Servo jewel_arm;  
  private Servo glyph_claw; 
  private Servo glyph_claw2;
  ColorSensor jewelSensor;
  IntegratingGyroscope gyro;
  RelicRecoveryVuMark vuMark;
  String message="";
  private VoltageSensor voltage;
  public ElapsedTime timer = new ElapsedTime();
  
  public void move(float forspeed,float sidespeed, float speed,double sec,int degrees) {
    double spin=0;
    timer.reset();
    boolean first=true;
    while ((timer.time() < sec || first)  && opModeIsActive()){
      first=false;
      angles = navX.getAngularOrientation(AxesReference.INTRINSIC, AxesOrder.ZYX, AngleUnit.DEGREES);
      angle=angles.firstAngle;
      
      
      error=angleDiff(angle,degrees); //Calculate Angle Differance
      
        spin=Math.max(Math.min(error,1),-1);
        //spin=spin/10.0;//Smoothing Factor: Bigger=Smoother
        //telemetry.addData("Spin",spin);
        m1.setPower(forspeed-sidespeed-spin);
        m2.setPower((-forspeed)-sidespeed-spin);
        m3.setPower((-forspeed)+sidespeed-spin);
        m4.setPower(forspeed+sidespeed-spin);
      
      
    }
    if(sec>0){
      m1.setPower(0);
      m2.setPower(0);
      m3.setPower(0);
      m4.setPower(0);
    }
  }
  private double angleDiff(double actualangle, double destangle)
  {
    double diffangle;
    diffangle = (actualangle - destangle) + 180;
    diffangle = (diffangle / 360.0);
    diffangle = ((diffangle - Math.floor( diffangle )) * 360.0) - 180;
    return diffangle;
  }
  public void turnTo(int degrees,float speed) {
    
    error=100;
    angles = navX.getAngularOrientation(AxesReference.INTRINSIC, AxesOrder.ZYX, AngleUnit.DEGREES);
    while (Math.abs(error)>maxTurnError && opModeIsActive()){
      angles = navX.getAngularOrientation(AxesReference.INTRINSIC, AxesOrder.ZYX, AngleUnit.DEGREES);
      m1.setPower(correction);
      m2.setPower(correction);
      m3.setPower(correction);
      m4.setPower(correction);
      angle=angles.firstAngle;
      
      
      error=angleDiff(angle,degrees); //Calculate Angle Differance
      correction=error/90;
      correction=-correction*speed;
      if(Math.abs(correction)<0.07){
        
        correction=0.07*Math.signum(correction);
        
      }
      //telemetry.addData("Angle:", angle);
      //telemetry.addData("Target:", degrees);
      //telemetry.addData("Error:", error);
      //telemetry.addData("Correction:", correction);
      //telemetry.update();
    }
    
    
  }
  public void moveDirection(float forspeed,float sidespeed,int speed,double sec,int degrees){
    turnTo(degrees,speed);
    move(forspeed, sidespeed, speed, sec, degrees);
  }
  @Override
  public void runOpMode(){
    
    
    
    voltage=hardwareMap.voltageSensor.get("Motor Controller 1");
    volts=voltage.getVoltage();
    telemetry.addData("Battery", volts+" volts");
    message="Battery is good.";
    if(volts<=1.0){
      message="Robot is off. Turn on the power switch and/or plug in the battery.";
    }else if(volts<9.0){
      message="Battery is too low! Charge it!";
    }
    telemetry.addData("Battery",message);
    telemetry.addData("Initialising","DO NOT START!");
    telemetry.update();
    
    gamepad1.setJoystickDeadzone(0);
    gamepad2.setJoystickDeadzone(0);
    //Motors
    m1 = hardwareMap.dcMotor.get("motor_1");
    m2 = hardwareMap.dcMotor.get("motor_2"); 
    m3 = hardwareMap.dcMotor.get("motor_3");
    m4 = hardwareMap.dcMotor.get("motor_4"); 
    glyph_boom = hardwareMap.dcMotor.get("boom"); 
    //Servos
    
    glyph_claw = hardwareMap.servo.get("glyph_claw"); 
    glyph_claw2 = hardwareMap.servo.get("glyph_claw2"); 
    //Sensors
    //jewelSensor = hardwareMap.colorSensor.get("jewel_sensor");
    navX = hardwareMap.get(NavxMicroNavigationSensor.class, "navX");
    cameraMonitorViewId = hardwareMap.appContext.getResources().getIdentifier("cameraMonitorViewId", "id", hardwareMap.appContext.getPackageName());
    //parameters = new VuforiaLocalizer.Parameters(cameraMonitorViewId);//With Cam Display
    parameters = new VuforiaLocalizer.Parameters();//No Cam Display
    parameters.cameraDirection = VuforiaLocalizer.CameraDirection.FRONT;
    parameters.vuforiaLicenseKey = "AU5SmTP/////AAAAGSFXPC/EJktQrceZYm14CJhzZL8oEl3e6rzgvdBq5rnBFeZ22N6GnU6cMirtp3/kFjrtgA5+V2KJEwUJD2hZnEZBs53ihltJ+jGFBR4q+FpzjflNW4zRoCymWU6gm+s31TTvaN3FQcOKdLO3u/HzErj3irP66IgkhV6aK1xGeM4uJB95imy2qDk+Sf6xNNgmSpEJnzqinzn+PnyuLlG68lqwsuhMga6/uT31kHnFGVn8dOHu4eoF2mYJcVJA9kD2m9Tv6Zqs4fZUoS/yMY4gYGzZkbafZDTAw6pNFO4XgvZ9XclsL+CdHUJJeEiSPLAlM48kB9P+LnJZUksiXp1sUZBR2VjadZ1OZ/fz8P9lDQmp";
    this.vuforia = ClassFactory.createVuforiaLocalizer(parameters);
    VuforiaTrackables relicTrackables = this.vuforia.loadTrackablesFromAsset("RelicVuMark");
    VuforiaTrackable relicTemplate = relicTrackables.get(0);
    relicTemplate.setName("relicVuMarkTemplate");
    relicTrackables.activate();
    
    gyro = (IntegratingGyroscope)navX;
    telemetry.addData("Calibrating gyro","Do not start");
    telemetry.update();
    while (navX.isCalibrating())  {
      navX = hardwareMap.get(NavxMicroNavigationSensor.class, "navX");
      //telemetry.addData("Info",navX.getAngularOrientatio(asxes reference,Axesorder,AngleUnit.DEGREES));
      angles = navX.getAngularOrientation(AxesReference.INTRINSIC, AxesOrder.ZYX, AngleUnit.DEGREES);
      
    }
    
    
    telemetry.addData("Initialized", "Ready to start.");
    telemetry.update();
    waitForStart();
    
   
  
    
    glyph_claw.setPosition(0.2);//Close claw
    glyph_claw2.setPosition(1-0.2);//Inverted
    move(0,-1,1,0.5,3);//Move left
    
    while (seenVuMark=="none" && opModeIsActive()){
      
    
      vuMark = RelicRecoveryVuMark.from(relicTemplate);
      if (vuMark==RelicRecoveryVuMark.RIGHT){
        seenVuMark="right";
      }else if (vuMark==RelicRecoveryVuMark.CENTER){
        seenVuMark="center";
      }else if (vuMark==RelicRecoveryVuMark.LEFT){
        seenVuMark="left";
      }
      
    }
    telemetry.update();
    telemetry.addData("vumark",seenVuMark);
    if(seenVuMark=="left"){
      distance=0.6;//1.575;
    }else if(seenVuMark=="center"){
      distance=1.2;
    }else if(seenVuMark=="right"){
      distance=1.85;
    }
    
    glyph_boom.setPower(-1);
    sleep(1000);
    glyph_boom.setPower(0);
    
    move(0,1,1,1.7,0);//Move over platform
    //timer.reset();
    /*while(tilt>2 && opModeIsActive()){
      angles = navX.getAngularOrientation(AxesReference.INTRINSIC, AxesOrder.ZYX, AngleUnit.DEGREES);
      tilt=angles.secondAngle;
      move(0,1,1,0,0);
      telemetry.log().clear(); 
      telemetry.addData("Tilt",tilt);
      telemetry.update();
      if(timer.time()>(0.4+distance)){
        tilt=0;//to force end
        distance=0;//just go forward
        telemetry.addData("Timed","out");
        telemetry.update();
        m1.setPower(0);
    m2.setPower(0);
    m3.setPower(0);
    m4.setPower(0);
        sleep(2000);
      };
    }
    m1.setPower(0);
    m2.setPower(0);
    m3.setPower(0);
    m4.setPower(0);
    *///TILT
   
    
    
    move(0,1,1,distance,0);//Align with column
    
    move(-1,0,1,1.5,0);//Push in block
    
    //glyph_boom.setPower(1);//Lower boom
    //sleep(750);
    //glyph_boom.setPower(0);
    
    glyph_claw.setPosition(0.5);//Open claw
    glyph_claw2.setPosition(1-0.5);//Inverted
   
    move(1,0,1,0.6,0);//Pull out
    
    
    
    
    //RESET
    glyph_boom.setPower(1);//Lower boom
    sleep(750);
    glyph_boom.setPower(0);
    //END RESET
    // forspeed, sidespeed, speed, sec, degrees            
      
      
      
      
      
      
    
    
  }
}
