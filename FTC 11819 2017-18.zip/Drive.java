
package org.firstinspires.ftc.teamcode;
import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import org.firstinspires.ftc.robotcore.external.ClassFactory;
import com.qualcomm.robotcore.eventloop.opmode.OpMode;
import com.qualcomm.robotcore.hardware.SwitchableLight;
import com.qualcomm.robotcore.hardware.VoltageSensor;
import com.qualcomm.robotcore.eventloop.opmode.TeleOp;
import com.qualcomm.robotcore.eventloop.opmode.Disabled;
import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.robotcore.hardware.DcMotorSimple;
import com.qualcomm.robotcore.util.ElapsedTime;
import com.qualcomm.robotcore.hardware.Servo;
import com.qualcomm.robotcore.hardware.CRServo;



//vuforia.com
//user: MadMachine
//pass:FTc118192017
//email: 11819@saintpeterrobotics.org
@TeleOp

public class Drive extends LinearOpMode {
  private DcMotor m1;
  private DcMotor m2;  
  private DcMotor m3;
  private DcMotor m4;
  private DcMotor glyph_boom;
  
  
  private Servo jewel_arm;
  private Servo glyph_claw;
  private Servo glyph_claw2;
  
  
  
  double x1l=0;
  
  
  double jewel_arm_pos=0.8;
  double glyph_boom_speed=0.0;
  double glyph_claw_pos=0.5;//0.6
  double spin=0;
  double y1l=0;
  double xfieldcor;
  double yfieldcor;
  double volts=0;
  double frame_percent=1;
  double last_time=0;
  double since_last_frame=0;
  String message="";
  private VoltageSensor voltage;
  
  @Override
  public void runOpMode() {
    
    
    
    voltage=hardwareMap.voltageSensor.get("Motor Controller 1");
    volts=voltage.getVoltage();
    telemetry.addData("Battery", volts+" volts");
    message="Battery is good.";
    if(volts<=1.0){
      message="Robot is off. Turn on the power switch and/or plug in the battery.";
    }
    else if(volts<9.0){
      message="Battery is too low! Charge it!";
    } 
    
    telemetry.addData("Battery",message);
    
    gamepad1.setJoystickDeadzone(0);
    gamepad2.setJoystickDeadzone(0);
    
    m1 = hardwareMap.dcMotor.get("motor_1");
    m2 = hardwareMap.dcMotor.get("motor_2"); 
    m3 = hardwareMap.dcMotor.get("motor_3");
    m4 = hardwareMap.dcMotor.get("motor_4"); 
    glyph_boom = hardwareMap.dcMotor.get("boom"); 
    
    jewel_arm  = hardwareMap.servo.get("jewel_arm");
    glyph_claw = hardwareMap.servo.get("glyph_claw"); 
    glyph_claw2 = hardwareMap.servo.get("glyph_claw2"); 
    
    telemetry.addData("Status", "Initialized");
    telemetry.update();
    waitForStart();
    
    // run until the end of the match (driver presses STOP)
    while (opModeIsActive()) {
      since_last_frame=this.time-last_time;
      last_time=this.time;
      
      
      
      
      
      x1l=this.gamepad1.left_stick_x;
      y1l=this.gamepad1.left_stick_y;
      spin=this.gamepad1.right_stick_x;
      //field oriented drive:
      xfieldcor =  0;//Math.sin(6);
      yfieldcor =  0;//Math.cos(6);
      x1l+=xfieldcor;
      y1l+=yfieldcor;
    
      m1.setPower(y1l-x1l-spin);
      m2.setPower((-y1l)-x1l-spin);
      m3.setPower((-y1l)+x1l-spin);
      m4.setPower(y1l+x1l-spin);
      
      
      
      //Boom Controls
      if(Math.abs(this.gamepad2.right_stick_y)>0.1){
        glyph_boom_speed=this.gamepad2.right_stick_y;
      }else{
        glyph_boom_speed=0;
      }
      
      
      
      //Glyph Claw Controls
      if(this.gamepad2.right_bumper){
        glyph_claw_pos=0.1;//Close
      }
      if(this.gamepad2.right_trigger>0.5){
        glyph_claw_pos=0.5;//Open
      }
      
      
      //Jewel Arm Controls
      if(this.gamepad2.left_bumper){
        jewel_arm_pos=0.8;//Up
      }
      if(this.gamepad2.left_trigger>0.5){
        jewel_arm_pos=0.2;//Down
      }
      
      
      
      
      
      glyph_claw.setPosition(glyph_claw_pos);
      glyph_claw2.setPosition(1-glyph_claw_pos);
      glyph_boom.setPower(glyph_boom_speed);
      jewel_arm.setPosition(jewel_arm_pos);
      
      
      
      telemetry.addData("Boom", glyph_boom_speed);
      telemetry.addData("Glyph Claw", glyph_claw_pos);
      telemetry.update();
      
      
      
      
      
    }
    
  }
}

